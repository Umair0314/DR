"use strict";
(() => {
  // background.ts
  var DEFAULT_BACKEND_URL = "https://dr-eosin-gamma.vercel.app";
  var REDIRECT_HOST_PERMISSIONS = ["https://*/*", "http://*/*"];
  var REDIRECT_TIMEOUT_MS = 3e3;
  var MAX_REDIRECT_CACHE_ENTRIES = 500;
  var redirectCache = /* @__PURE__ */ new Map();
  var redirectRequests = /* @__PURE__ */ new Map();
  function isRedirectStatus(status) {
    return status === 301 || status === 302 || status === 307 || status === 308;
  }
  function destinationFrom(response, sourceUrl) {
    if (!isRedirectStatus(response.status)) {
      return response.status >= 200 && response.status < 300 || response.status >= 400 && response.status < 500 && ![403, 405].includes(response.status) ? { status: "no" } : { status: "unknown" };
    }
    const location = response.headers.get("Location");
    if (!location) return { status: "unknown" };
    try {
      const destination = new URL(location, sourceUrl);
      if (destination.protocol !== "http:" && destination.protocol !== "https:") {
        return { status: "unknown" };
      }
      return {
        status: "yes",
        destination: destination.hostname.replace(/^www\./i, "")
      };
    } catch {
      return { status: "unknown" };
    }
  }
  async function requestRedirectHeaders(url, method, deadline) {
    const remaining = deadline - Date.now();
    if (remaining <= 0) return null;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), remaining);
    try {
      return await fetch(url, {
        method,
        redirect: "manual",
        credentials: "omit",
        cache: "no-store",
        signal: controller.signal
      });
    } finally {
      clearTimeout(timeout);
    }
  }
  async function detectRedirect(url) {
    let parsedUrl;
    try {
      parsedUrl = new URL(url);
    } catch {
      return { status: "unknown" };
    }
    if (parsedUrl.protocol !== "http:" && parsedUrl.protocol !== "https:") {
      return { status: "unknown" };
    }
    parsedUrl.hash = "";
    const sourceUrl = parsedUrl.href;
    const deadline = Date.now() + REDIRECT_TIMEOUT_MS;
    let headResponse = null;
    try {
      headResponse = await requestRedirectHeaders(sourceUrl, "HEAD", deadline);
    } catch {
      if (Date.now() >= deadline) return { status: "unknown" };
    }
    if (headResponse) {
      if (headResponse.type !== "opaqueredirect" && headResponse.status !== 0) {
        if (isRedirectStatus(headResponse.status)) {
          return destinationFrom(headResponse, sourceUrl);
        }
        if (![403, 405, 501].includes(headResponse.status)) {
          return destinationFrom(headResponse, sourceUrl);
        }
      }
    }
    if (Date.now() >= deadline) return { status: "unknown" };
    let getResponse;
    const controller = new AbortController();
    const timeout = setTimeout(
      () => controller.abort(),
      Math.max(0, deadline - Date.now())
    );
    try {
      getResponse = await fetch(sourceUrl, {
        method: "GET",
        redirect: "manual",
        credentials: "omit",
        cache: "no-store",
        signal: controller.signal
      });
      controller.abort();
    } catch {
      return { status: "unknown" };
    } finally {
      clearTimeout(timeout);
    }
    if (!getResponse || getResponse.type === "opaqueredirect" || getResponse.status === 0) {
      return { status: "unknown" };
    }
    return destinationFrom(getResponse, sourceUrl);
  }
  function rememberRedirect(url, result) {
    redirectCache.delete(url);
    redirectCache.set(url, result);
    if (redirectCache.size > MAX_REDIRECT_CACHE_ENTRIES) {
      const oldestKey = redirectCache.keys().next().value;
      if (oldestKey) redirectCache.delete(oldestKey);
    }
  }
  function getRedirectResult(url) {
    return chrome.permissions.contains({ origins: REDIRECT_HOST_PERMISSIONS }).then((hasPermission) => {
      if (!hasPermission) return { status: "unknown" };
      const cached = redirectCache.get(url);
      if (cached) return cached;
      const pending = redirectRequests.get(url);
      if (pending) return pending;
      const request = detectRedirect(url).catch(() => ({ status: "unknown" })).then((result) => {
        rememberRedirect(url, result);
        return result;
      }).finally(() => redirectRequests.delete(url));
      redirectRequests.set(url, request);
      return request;
    });
  }
  chrome.runtime.onInstalled.addListener(async () => {
    const { enabled, backendUrl } = await chrome.storage.local.get(["enabled", "backendUrl"]);
    const defaults = {};
    if (enabled === void 0) defaults.enabled = true;
    if (!backendUrl || backendUrl === "http://localhost:3000") {
      defaults.backendUrl = DEFAULT_BACKEND_URL;
    }
    if (Object.keys(defaults).length) await chrome.storage.local.set(defaults);
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || typeof message !== "object" || message.type !== "CHECK_REDIRECT" || typeof message.url !== "string") {
      return false;
    }
    void getRedirectResult(message.url).then(sendResponse);
    return true;
  });
})();
