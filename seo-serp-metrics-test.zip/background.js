"use strict";
(() => {
  // background.ts
  var DEFAULT_BACKEND_URL = "https://dr-eosin-gamma.vercel.app";
  chrome.runtime.onInstalled.addListener(async () => {
    const { enabled, backendUrl } = await chrome.storage.local.get(["enabled", "backendUrl"]);
    const defaults = {};
    if (enabled === void 0) defaults.enabled = true;
    if (!backendUrl || backendUrl === "http://localhost:3000") {
      defaults.backendUrl = DEFAULT_BACKEND_URL;
    }
    if (Object.keys(defaults).length) await chrome.storage.local.set(defaults);
  });
})();
