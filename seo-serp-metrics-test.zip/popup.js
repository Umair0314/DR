"use strict";
(() => {
  // popup.ts
  var enabledToggle = document.querySelector("#enabled");
  var status = document.querySelector("#status");
  var settingsButton = document.querySelector("#settings");
  var version = document.querySelector("#version");
  var redirectPermissionStatus = document.querySelector("#redirect-permission-status");
  var enableRedirectChecksButton = document.querySelector("#enable-redirect-checks");
  var auditButton = document.querySelector("#seo-audit");
  var REDIRECT_HOST_PERMISSIONS = ["https://*/*", "http://*/*"];
  var AUDIT_URL = "https://umairdigital.vercel.app";
  async function load() {
    if (!enabledToggle || !status || !version) return;
    const [values, manifest] = await Promise.all([
      chrome.storage.local.get("enabled"),
      Promise.resolve(chrome.runtime.getManifest())
    ]);
    enabledToggle.checked = values.enabled !== false;
    version.textContent = `Version ${manifest.version}`;
    updateStatus();
    await updateRedirectPermissionStatus();
  }
  function updateStatus() {
    if (enabledToggle && status) status.textContent = enabledToggle.checked ? "Status: Enabled" : "Status: Disabled";
  }
  enabledToggle?.addEventListener("change", async () => {
    await chrome.storage.local.set({ enabled: enabledToggle.checked });
    updateStatus();
  });
  settingsButton?.addEventListener("click", () => {
    void chrome.runtime.openOptionsPage();
  });
  async function updateRedirectPermissionStatus() {
    const granted = await chrome.permissions.contains({
      origins: REDIRECT_HOST_PERMISSIONS
    });
    if (redirectPermissionStatus) {
      redirectPermissionStatus.textContent = granted ? "Redirect checks are enabled." : "Redirect checks need optional access to all websites.";
    }
    if (enableRedirectChecksButton) enableRedirectChecksButton.hidden = granted;
  }
  enableRedirectChecksButton?.addEventListener("click", async () => {
    if (!redirectPermissionStatus) return;
    const granted = await chrome.permissions.request({
      origins: REDIRECT_HOST_PERMISSIONS
    });
    redirectPermissionStatus.textContent = granted ? "Enabled. Refresh Google results to check redirects." : "Site access was not granted; redirects will show Unknown.";
    if (granted && enableRedirectChecksButton) enableRedirectChecksButton.hidden = true;
  });
  auditButton?.addEventListener("click", () => {
    void chrome.tabs.create({ url: AUDIT_URL });
  });
  void load();
})();
