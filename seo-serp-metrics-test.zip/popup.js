"use strict";
(() => {
  // popup.ts
  var enabledToggle = document.querySelector("#enabled");
  var status = document.querySelector("#status");
  var settingsButton = document.querySelector("#settings");
  var version = document.querySelector("#version");
  async function load() {
    if (!enabledToggle || !status || !version) return;
    const [values, manifest] = await Promise.all([
      chrome.storage.local.get("enabled"),
      Promise.resolve(chrome.runtime.getManifest())
    ]);
    enabledToggle.checked = values.enabled !== false;
    version.textContent = `Version ${manifest.version}`;
    updateStatus();
  }
  function updateStatus() {
    if (enabledToggle && status) status.textContent = enabledToggle.checked ? "Status: Enabled" : "Status: Disabled";
  }
  enabledToggle?.addEventListener("change", async () => {
    await chrome.storage.local.set({ enabled: enabledToggle.checked });
    updateStatus();
  });
  settingsButton?.addEventListener("click", () => {
    void chrome.runtime.openOptionsPage();
  });
  void load();
})();
